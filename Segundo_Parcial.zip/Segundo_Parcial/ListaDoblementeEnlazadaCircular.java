public class ListaDoblementeEnlazadaCircular {
    private Nodo cabeza;

    public ListaDoblementeEnlazadaCircular() {
        cabeza = null;
    }

    public void insertarInicio(int dato) {
        Nodo nuevo = new Nodo(dato);

        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            Nodo ultimo = cabeza.anterior;

            nuevo.siguiente = cabeza;
            nuevo.anterior = ultimo;

            cabeza.anterior = nuevo;
            ultimo.siguiente = nuevo;

            cabeza = nuevo;
        }
    }

    public void mostrar() {
        if (cabeza == null) {
            System.out.println("Lista vacía");
            return;
        }

        Nodo actual = cabeza;
        do {
            System.out.print(actual.dato + " <-> ");
            actual = actual.siguiente;
        } while (actual != cabeza);

        System.out.println("(inicio)");
    }
}
