public class Main {
    public static void main(String[] args) {

        ListaDoblementeEnlazadaCircular lista =
                new ListaDoblementeEnlazadaCircular();

        lista.insertarInicio(10);
        lista.insertarInicio(20);
        lista.insertarInicio(30);

        lista.mostrar();
    }
}
